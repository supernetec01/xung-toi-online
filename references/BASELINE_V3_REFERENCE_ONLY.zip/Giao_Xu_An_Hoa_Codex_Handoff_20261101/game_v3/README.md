# Giáo Xứ An Hòa V3 — Source prototype

Đây là source game V3 (HTML/CSS/JavaScript/SVG), không phải bản production; đọc `../START_HERE.md` trước khi chỉnh sửa.

- Chạy: mở `Giao_Xu_An_Hoa_Choi_Thu_V3.html` hoặc phục vụ `index.html` bằng web server tĩnh.
- Test nội dung: `node tests/validate_content.cjs` và `node tests/validate_v3.cjs`.
- Specs gốc: `docs/CODEX_V3_IMPLEMENTATION.md`, `docs/schema_v3.sql`.
- Không tự động thay QR placeholder bằng QR cá nhân; không dùng localStorage làm server wallet.
