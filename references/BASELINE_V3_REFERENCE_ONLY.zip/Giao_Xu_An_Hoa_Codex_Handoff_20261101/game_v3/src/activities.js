
// Các hoạt động sinh hoạt lặp lại: thưởng Xu chỉ là cơ chế game, KHÔNG là công phúc/ân xá.
window.PARISH_ACTIVITIES = [
 {id:'sign_cross',icon:'✝️',name:'Tìm hiểu và làm dấu Thánh giá',scene:'nave',cooldown:60,coins:2,pose:'cross',seconds:2,category:'cau_nguyen',tip:'Tư thế cầu nguyện của người Công giáo; thao tác trong game là minh họa.'},
 {id:'bow',icon:'🙇',name:'Cúi mình tôn kính',scene:'nave',cooldown:90,coins:2,pose:'bow',seconds:2,category:'cau_nguyen',tip:'Cúi mình trước bàn thờ theo đúng bối cảnh; không đi vào cung thánh.'},
 {id:'genuflect',icon:'🕊️',name:'Tìm hiểu động tác bái gối',scene:'nave',cooldown:120,coins:2,pose:'kneel',seconds:2,category:'cau_nguyen',tip:'Bái gối một gối khi tôn kính Thánh Thể nơi Nhà Tạm; tùy tình trạng sức khỏe và bối cảnh.'},
 {id:'quiet',icon:'🙏',name:'Ngồi thinh lặng cầu nguyện',scene:'nave',cooldown:180,coins:3,pose:'pray',seconds:3,category:'cau_nguyen',tip:'Một khoảnh khắc tĩnh tâm; thời gian animation không thay thế việc cầu nguyện thực tế.'},
 {id:'prayer',icon:'📖',name:'Đọc kinh chung',scene:'nave',cooldown:240,coins:4,pose:'pray',seconds:3,category:'cau_nguyen',tip:'Giới thiệu những lời kinh đơn giản; không giả lập Thánh lễ hay thay cho tham dự lễ thật.'},
 {id:'candle',icon:'🕯️',name:'Thắp nến tại góc cầu nguyện',scene:'nave',cooldown:300,coins:4,pose:'pray',seconds:3,category:'cau_nguyen',tip:'Chỉ thực hiện tại nơi giáo xứ cho phép; không thắp nến tùy ý ở bàn thờ.'},
 {id:'pew_clean',icon:'🧽',name:'Lau ghế khi không có Thánh lễ',scene:'nave',cooldown:240,coins:8,pose:'clean',seconds:3,category:'phuc_vu',tip:'Việc vệ sinh diễn ra ngoài thời gian cử hành phụng vụ.'},
 {id:'sweep',icon:'🧹',name:'Quét sân giáo xứ',scene:'courtyard',cooldown:120,coins:7,pose:'sweep',seconds:3,category:'phuc_vu',tip:'Quét một phần sân, hoàn thành sẽ nhận Xu.'},
 {id:'welcome',icon:'🤝',name:'Đón tiếp khách đến giáo xứ',scene:'foyer',cooldown:180,coins:6,pose:'wave',seconds:2,category:'phuc_vu',tip:'Chỉ dẫn khách đến đúng khu vực bằng lời nói lịch sự.'},
 {id:'water',icon:'🌼',name:'Tưới hoa trong vườn',scene:'garden',cooldown:180,coins:8,pose:'water',seconds:3,category:'phuc_vu',tip:'Tưới hoa và chăm sóc vườn cộng đồng.'},
 {id:'books',icon:'📚',name:'Sắp xếp sách giáo lý',scene:'classroom',cooldown:180,coins:8,pose:'clean',seconds:3,category:'phuc_vu',tip:'Trả sách về đúng kệ ở lớp giáo lý.'},
 {id:'gifts',icon:'🎁',name:'Chuẩn bị quà sẻ chia',scene:'office',cooldown:300,coins:12,pose:'clean',seconds:3,category:'phuc_vu',tip:'Sắp những món quà thiết yếu cho cư dân cần hỗ trợ.'},
 {id:'choir',icon:'🎼',name:'Tập hát cùng ca đoàn',scene:'choir',cooldown:300,coins:7,pose:'sing',seconds:3,category:'sinh_hoat',tip:'Minigame nhịp điệu nguyên bản, không sử dụng tác phẩm âm nhạc có bản quyền.'},
 {id:'noel',icon:'🌟',name:'Trang trí khu Noel',scene:'christmas',cooldown:600,coins:15,pose:'decorate',seconds:3,category:'sinh_hoat',tip:'Treo ngôi sao, gắn đèn hoặc giúp sắp các hộp quà.'}
];
// Một điểm tương tác mở menu tác vụ để giữ cảnh 2D sạch, tránh dày đặc icon.
const ACTION_HUB_POS = {nave:[78,86],courtyard:[53,77],foyer:[79,76],garden:[56,83],classroom:[75,78],office:[75,83],choir:[75,80],christmas:[60,81]};
for(const [scene,[x,y]] of Object.entries(ACTION_HUB_POS)){
 window.PARISH_DATA.scenes[scene].spots.push(['action_hub_'+scene,'🙌','Hành động tại đây',x,y,'activity_hub']);
}
